# torchplus
additional functions and modules for pytorch. will be a submodule of my deeplearning project.
